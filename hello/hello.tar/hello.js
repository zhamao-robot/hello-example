alert("hello world");
